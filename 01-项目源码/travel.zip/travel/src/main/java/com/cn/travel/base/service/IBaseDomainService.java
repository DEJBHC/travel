package com.cn.travel.base.service;

public interface IBaseDomainService {
}
